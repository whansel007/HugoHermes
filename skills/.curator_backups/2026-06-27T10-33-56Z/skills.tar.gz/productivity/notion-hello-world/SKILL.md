---
name: notion-hello-world
description: Simple test to verify Notion API integration by creating a 'Hello World' page.
---

# notion-hello-world

This skill provides a simple way to test the Notion API connection by creating a page in a specified database.

## Usage
Run the following script to create a "Hello World" page in your designated test database.

## Prerequisites
- Notion API key must be configured in `ntn` CLI.
- Database ID for the test must be available.
