---
name: notion-patch-task
description: Patch a Notion task in a database using a reliable Python script.
---

# notion-patch-task

This skill uses a Python script to reliably update Notion database tasks, avoiding shell quote issues.

## Usage
1. Define the `page_id` and the `data` (JSON properties to update).
2. The script uses the `requests` library to send a `PATCH` request to the Notion API.

## Python Script Template
```python
import requests
import os
import json

page_id = "YOUR_PAGE_ID"
api_token = os.environ.get("NOTION_API_KEY")

# Define the properties to update
data = {
    "properties": {
        "Date": {
            "date": {
                "start": "2026-06-21T19:00:00+08:00",
                "end": "2026-06-21T19:30:00+08:00"
            }
        }
    }
}

headers = {
    "Authorization": f"Bearer {api_token}",
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json"
}

response = requests.patch(f"https://api.notion.com/v1/pages/{page_id}", headers=headers, json=data)
print(response.json())
```
