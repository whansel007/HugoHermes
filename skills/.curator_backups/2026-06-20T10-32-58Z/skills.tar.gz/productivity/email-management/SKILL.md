---
name: email-management
description: "Guidelines for managing emails, including triage workflows and formatting preferences."
---

# Email Management
Conventions for triaging and replying to emails.

## Custom Triage Script
A user-provided Python script for fetching email envelopes. It depends on a shell script wrapper for the underlying `himalaya` command.

- **Source:** `scripts/get_emails.py` (ensure chmod +x)
- **Dependency:** `~/.hermes/scripts/himalaya_list.sh`
- **Deployment:** Use agent-managed cron jobs for execution to ensure environment/path consistency.

## Formatting Preferences
- **Email List View:** 
  ✉️ [ID]
  Subject: [Subject]
  From: [From]
  (Separate entries with an extra newline).

## Workflow
- **Filtering:** Always filter to show only **unread** (flagged) emails.
- **Automated Check:** When using custom scripts (e.g., `get_emails.py`) for triage, ensure they follow the [Formatting Preferences](#formatting-preferences) strictly.
- **Maintenance:** Scripts MUST be placed in `~/.hermes/scripts/`, be executable (`chmod +x`), and be self-contained or explicitly configured with relative paths to dependencies.
- **Workflow:** Prioritize using the user-provided script for triage checks before performing manual agent-driven lookups.

## Style & Tone
- **Voice:** Direct, clear, friendly.
- **Italics:** Use single asterisks (*).
- **Spacing:** Always start a new line after every emoji.
