---
name: email-reply-workflow
description: "A robust workflow for replying to emails using himalaya CLI with template injection."
---

# Email Reply Workflow

This workflow uses a template injection technique to avoid issues with empty messages or malformed pipes.

## Prerequisites
- `himalaya` CLI configured.
- A temp file for your message body.

## Steps

1. **Create the message body:**
   ```bash
   echo "Your message here" > /tmp/msg_body.txt
   ```

2. **Generate and inject the reply:**
   Generate the template for the email ID, then use `sed` to inject your body text after the 'Subject:' line:
   ```bash
   himalaya template reply <ID> > /tmp/hugo_reply.txt
   sed -i '/Subject:/r /tmp/msg_body.txt' /tmp/hugo_reply.txt
   ```

3. **Send the email:**
   ```bash
   cat /tmp/hugo_reply.txt | himalaya template send
   ```

## Alternative (Interactive)
For simpler, single-message replies, just use the built-in editor:
```bash
himalaya message reply <ID>
```
*This opens your default terminal editor (nano/vi), saves, and sends automatically upon exit.*
