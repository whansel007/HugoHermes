---
name: science-briefing-formatter
description: "A standardized formatter for fetching and presenting science papers."
---

# Science Briefing Formatter

Use this format to present papers to the user:

✉️ [Title]
Link: [URL]
Summary: [Summary]

(For the 4th/random paper, prefix with "The wild card paper" above the title).
