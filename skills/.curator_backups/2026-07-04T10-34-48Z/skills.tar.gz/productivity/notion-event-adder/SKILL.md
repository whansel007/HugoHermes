---
name: notion-event-adder
description: Add events to Notion database using event_details.json and notion_add.py.
---

### Event Details JSON Structure
The script `notion_add.py` requires a JSON file at `/root/.hermes/scripts/notion/event_details.json` with the following keys. Note that empty fields are acceptable, though explicitly providing data (especially for date/time) is preferred.

```json
{
  "title": "Event Title",
  "startDate": "YYYY-MM-DD",
  "startTime": "HH:MM",
  "endDate": "YYYY-MM-DD",
  "endTime": "HH:MM",
  "location": "Venue",
  "priority": "Medium",
  "tag": "Events",
  "status": "Not started"
}
```

### Preference: User Notification
After every successful execution of `notion_add.py`, I MUST:
1. Summarize the event details added.
2. Provide the direct URL of the created Notion page.
3. This is a mandatory communication step regardless of how 'automatic' the background process feels.

### Valid Values
- __Valid Tags__: "Life, Events, Career, Personal Project, Organization, Competition, School, Other".
- __Valid Priorities__: "Low, Medium, High, CRITICAL".
- __Valid Statuses__: "Not started, In progress, Done".
